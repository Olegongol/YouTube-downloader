import yt_dlp
import os
#from pydub import AudioSegment

bubka = os.path.dirname(os.path.abspath(__file__))
piskabobra = os.path.join(bubka, "%(title)s.%(ext)s")

while True:

    goi = input('Link here: ').strip()  
    pupka = input('choice format, 1 for video 2 for audio ')

    audio_opts = {
        "format" : "bestaudio/best",
        "outtmpl" : piskabobra,
        #"postprocessors": [{
        #    "key": "FFmpegExtractAudio",
        #    "preferredcodec": "mp3",
        #    "preferredquality": "192",
        #}]
    }
    
    ydl_opts = {
        "format" : "best",
        "outtmpl" : piskabobra,
        #"postprocessors": [{
        #    "key": "FFmpegExtractAudio",
        #    "preferredcodec": "mp4",
        #    "preferredquality": "192",
        #}]
    }

    if pupka == '1' :
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download(goi)

    elif pupka == "2":
        with yt_dlp.YoutubeDL(audio_opts) as ydl:
            ydl.download(goi)

    else :
        print('Долбаёб, по людски написано 1 или 2')