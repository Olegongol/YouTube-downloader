import os
import sys
import spotdl
from yt_dlp import YoutubeDL
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.core.window import Window
import traceback


base_path = os.path.dirname(os.path.abspath(__file__))
download_folder = os.path.join(base_path, "downloads")
os.makedirs(download_folder, exist_ok=True)
output_template = os.path.join(download_folder, "%(title)s.%(ext)s")


audio_opts = {
    "format": "bestaudio/best",
    "outtmpl": output_template,
    "postprocessors": [
        {
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }
    ],
    "quiet": True,
    "no_warnings": True
}

video_opts = {
    "format": "best",
    "outtmpl": output_template,
    "quiet": True,
    "no_warnings": True
}


class DownloaderLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=10, spacing=10, **kwargs)

        self.url_input = TextInput(hint_text="Enter video link:", multiline=False)
        self.add_widget(self.url_input)

        self.format_spinner = Spinner(
            text='Choose format',
            values=('Video', 'Audio'),
            size_hint=(1, None),
            height=44
        )
        self.add_widget(self.format_spinner)

        self.status_label = Label(text="", size_hint=(1, None), height=40)
        self.add_widget(self.status_label)

        self.download_button = Button(text="Download", size_hint=(1, None), height=50)
        self.download_button.bind(on_press=self.download_media)
        self.add_widget(self.download_button)

    def download_media(self, instance):
        url = self.url_input.text.strip()
        format_choice = self.format_spinner.text

        if not url:
            self.status_label.text = "Please, enter a link"
            return

        opts = video_opts if format_choice == 'Video' else audio_opts

        try:
            self.status_label.text = "Download started..."
            self.status_label.color = (1, 1, 0, 1)  #yellow
            self.status_label.canvas.ask_update()

            with YoutubeDL(opts) as ydl:
                ydl.download([url])

            self.status_label.text = "Download complete"
            self.status_label.color = (0, 1, 0, 1)  # green

        except Exception as e:
            print("Download error:", file=sys.stderr)
            traceback.print_exc()
            self.status_label.text = f"Error: {str(e)}"
            self.status_label.color = (1, 0, 0, 1)  # red


class YTDownloaderApp(App):
    def build(self):
        self.title = "YouTube Downloader"
        Window.size = (400, 300)
        return DownloaderLayout()


if __name__ == '__main__':
    YTDownloaderApp().run()
