import yt_dlp
import os
#from pydub import AudioSegment

bubka = os.path.dirname(os.path.abspath(__file__))
download_dir = os.path.join(bubka, "downloads")
os.makedirs(download_dir, exist_ok=True)
bomj = os.path.join(download_dir, "%(title)s.%(ext)s")

gacha = ('https://youtu.be/aMQTv2_GWH8?si=YLLCEi1DWIzraXLv').strip()

audio_opts = {
    "format" : "bestaudio/best",
    "outtmpl" : bomj,
    #"postprocessors": [{
    #    "key": "FFmpegExtractAudio",
    #    "preferredcodec": "mp3",
    #    "preferredquality": "192",
    #}]
}
    
ydl_opts = {
    "format" : "best",
    "outtmpl" : bomj,
    #"postprocessors": [{
    #    "key": "FFmpegExtractAudio",
    #    "preferredcodec": "mp4",
    #    "preferredquality": "192",
    #}]
}


while True:

    goi = input('Link here: ').strip()  
    pupka = input('choice format, 1 for video 2 for audio ')

    if pupka == '1' :
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download(goi)

    elif pupka == "2":
        with yt_dlp.YoutubeDL(audio_opts) as ydl:
            ydl.download(goi)

    else :
       print ('Fuck you nigga')
       with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download(gacha)